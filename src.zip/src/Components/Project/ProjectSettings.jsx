import React from 'react'

export default function ProjectSettings() {
  return (
    <div>Project's Settings</div>
  )
}
