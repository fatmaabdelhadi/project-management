import React from 'react'

export default function Gannt() {
  return (
    <div>Gannt</div>
  )
}
